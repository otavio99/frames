package br.com.viagemaerea.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import br.com.viagemaerea.model.Aeroporto;
import br.com.viagemaerea.service.ServiceAeroporto;

@Controller
@RequestMapping("/aeroportos")
public class ControllerAeroporto {
	
	@Autowired
	private ServiceAeroporto serviceAeroporto;
	
	@GetMapping
	public ModelAndView listarAeroportos() {
		ModelAndView mv = new ModelAndView("ListaAeroporto");
		mv.addObject("aeroportos", serviceAeroporto.findAll() );
		return mv;
	}
	
	@GetMapping("/addAeroporto")
	public ModelAndView adicionaAeroporto() {
		ModelAndView mv = new ModelAndView("AddAeroporto");
		mv.addObject(new Aeroporto());
		return mv;
	}
	
	@PostMapping("/addAeroporto")
	public String save(Aeroporto aeroporto, RedirectAttributes atributos ) {
		serviceAeroporto.save(aeroporto);
		atributos.addFlashAttribute("mensagem","Aeroporto gravado com sucesso!");
		return "redirect:/aeroportos";
	}
	
	@GetMapping("/editarAeroporto/{id}")
	public ModelAndView editarAeroporto(@PathVariable ("id") Long id) {
		ModelAndView mv = new ModelAndView("AddAeroporto");
		mv.addObject("aeroporto", serviceAeroporto.findById(id));
		return mv;
	}
	
	@GetMapping("/deletarAeroporto/{id}")
	public String deletarAeroporto(@PathVariable ("id") Long id) {
		if(serviceAeroporto.listaVoo(id).size() == 0)
			serviceAeroporto.deleteById(id);
		return "redirect:/aeroportos";
	}
	
}
