package br.com.viagemaerea.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import br.com.viagemaerea.model.Cliente;
import br.com.viagemaerea.service.ServiceCliente;

@Controller
@RequestMapping("/clientes")
public class ControllerCliente {
	
	@Autowired
	private ServiceCliente serviceCliente;
	
	@GetMapping
	public ModelAndView listaClientes() {
		ModelAndView mv = new ModelAndView("ListaCliente");
		mv.addObject("clientes", serviceCliente.findAll());
		return mv;
	}
	
	@GetMapping("/addCliente")
	public ModelAndView adicionaCliente() {
		ModelAndView mv = new ModelAndView("AddCliente");
		mv.addObject(new Cliente());
		return mv;
	}
	
	@PostMapping("/addCliente")
	public String save(Cliente cliente, RedirectAttributes atributos) {
		serviceCliente.save(cliente);
		atributos.addFlashAttribute("mensagem","Cliente Salvo com Sucesso!");
		return "redirect:/clientes";
	}
	
	@GetMapping("/editarCliente/{id}")
	public ModelAndView editarCliente(@PathVariable ("id") Long id) {
		ModelAndView mv = new ModelAndView("AddCliente");
		mv.addObject("cliente", serviceCliente.findById(id));
		return mv;
	}
	
	@GetMapping("/deletarCliente/{id}")
	public String deletarCliente(@PathVariable ("id") Long id) {
		if (serviceCliente.listaPassagem(id).size() == 0)
			serviceCliente.deleteById(id);
		return "redirect:/clientes";
	}

}
