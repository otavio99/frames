package br.com.viagemaerea.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import br.com.viagemaerea.model.Voo;
import br.com.viagemaerea.service.ServiceAeroporto;
import br.com.viagemaerea.service.ServiceAviao;
import br.com.viagemaerea.service.ServiceVoo;

@Controller
@RequestMapping("/voos")
public class ControllerVoo {
	@Autowired
	private ServiceVoo serviceVoo;
	
	@Autowired
	private ServiceAviao serviceAviao;
	
	@Autowired
	private ServiceAeroporto serviceAeroporto;
	
	@GetMapping
	public ModelAndView listarVoos() {
		ModelAndView mv = new ModelAndView("ListaVoo");
		mv.addObject("voos", serviceVoo.findAll());
		return mv;
	}
	
	@GetMapping("/addVoo")
	public ModelAndView adicionarVoo() {
		ModelAndView mv = new ModelAndView("AddVoo");
		mv.addObject(new Voo());
		mv.addObject("listaAvioes", serviceAviao.findAll());
		mv.addObject("listaAeroportos", serviceAeroporto.findAll());
		return mv;
	}
	
	@PostMapping("/addVoo")
	public String save(Voo voo, RedirectAttributes atributos) {
		serviceVoo.save(voo);
		atributos.addFlashAttribute("mensagem", "Voo registrado com sucesso!");
		return "redirect:/voos";
	}
	
	@GetMapping("/editarVoo/{id}")
	public ModelAndView editarVoo(@PathVariable ("id") Long id) {
		ModelAndView mv = new ModelAndView("AddVoo");
		mv.addObject("voo", serviceVoo.findById(id));
		mv.addObject("listaAvioes", serviceAviao.findAll());
		mv.addObject("listaAeroportos", serviceAeroporto.findAll());
		return mv;
	}
	
	@GetMapping("/deletarVoo/{id}")
	public String deletarVoo(@PathVariable ("id") Long id) {
		serviceVoo.deleteById(id);
		return "redirect:/voos";
	}

}
