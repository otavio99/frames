package br.com.viagemaerea.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import br.com.viagemaerea.model.Aviao;
import br.com.viagemaerea.service.ServiceAviao;

@Controller
@RequestMapping("/avioes")
public class ControllerAviao {
	@Autowired
	private ServiceAviao serviceAviao;
	
	@GetMapping
	public ModelAndView listarAvioes() {
		ModelAndView mv = new ModelAndView("ListaAviao");
		mv.addObject("avioes", serviceAviao.findAll());
		return mv;
	}
	
	@GetMapping("/addAviao")
	public ModelAndView adicionarAviao() {
		ModelAndView mv = new ModelAndView("AddAviao");
		mv.addObject(new Aviao());
		return mv;
	}
	
	@PostMapping("/addAviao")
	public String save(Aviao aviao, RedirectAttributes atributos) {
		serviceAviao.save(aviao);
		atributos.addFlashAttribute("mensagem", "Avião salvo com sucesso!");
		return "redirect:/avioes";
	}
	
	@GetMapping("/editarAviao/{id}")
	public ModelAndView editarAviao(@PathVariable ("id") Long id) {
		ModelAndView mv = new ModelAndView("AddAviao");
		mv.addObject("aviao", serviceAviao.findById(id));
		return mv;
	}
	
	@GetMapping("/deletarAviao/{id}")
	public String deletarAviao(@PathVariable ("id") Long id) {
		serviceAviao.deleteById(id);
		return "redirect:/avioes";
	}

}
