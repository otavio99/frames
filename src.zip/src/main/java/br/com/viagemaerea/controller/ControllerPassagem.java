package br.com.viagemaerea.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import br.com.viagemaerea.model.Passagem;
import br.com.viagemaerea.service.ServiceCliente;
import br.com.viagemaerea.service.ServicePassagem;
import br.com.viagemaerea.service.ServiceVoo;

@Controller
@RequestMapping("/passagens")
public class ControllerPassagem {
	
	@Autowired
	private ServicePassagem servicePassagem;
	@Autowired
	private ServiceCliente serviceCliente;
	@Autowired
	private ServiceVoo serviceVoo;
	
	@GetMapping
	public ModelAndView listarPassagem() {
		ModelAndView mv = new ModelAndView("ListaPassagem");
		mv.addObject("passagens", servicePassagem.findAll());
		return mv;
	}
	
	@GetMapping("/addPassagem")
	public ModelAndView adicionarPassagem() {
		ModelAndView mv = new ModelAndView("AddPassagem");
		mv.addObject(new Passagem());
		mv.addObject("listaClientes", serviceCliente.findAll());
		mv.addObject("listaVoos", serviceVoo.findAll());
		return mv;
	}
	
	@PostMapping("/addPassagem")
	public String save(Passagem passagem, RedirectAttributes atributos) {
		servicePassagem.save(passagem);
		atributos.addFlashAttribute("mensagem", "Passagem registrada com sucesso!");
		return "redirect:/passagens";
	}
	
	@GetMapping("/editarPassagem/{id}")
	public ModelAndView editarPassagem(@PathVariable ("id") Long id) {
		ModelAndView mv = new ModelAndView("AddPassagem");
		mv.addObject("passagem", servicePassagem.findById(id));
		mv.addObject("listaClientes", serviceCliente.findAll());
		mv.addObject("listaVoos", serviceVoo.findAll());
		return mv;
	}
	
	@GetMapping("/deletarPassagem/{id}")
	public String deletarPassagem(@PathVariable ("id") Long id) {
		servicePassagem.deleteById(id);
		return "redirect:/passagens";
	}

}
