package br.com.viagemaerea.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import br.com.viagemaerea.model.Aeroporto;

@Repository
public interface RepositoryAeroporto extends JpaRepository<Aeroporto, Long>{

}
