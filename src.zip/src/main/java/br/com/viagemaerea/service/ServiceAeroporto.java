package br.com.viagemaerea.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import br.com.viagemaerea.model.Aeroporto;
import br.com.viagemaerea.model.Voo;
import br.com.viagemaerea.repository.RepositoryAeroporto;

@Service
public class ServiceAeroporto {
	
	@Autowired
	private RepositoryAeroporto aeroportos;
	
	public List<Aeroporto> findAll(){
		return aeroportos.findAll();
	}
	
	public void save(Aeroporto aeroporto) {
		aeroportos.saveAndFlush(aeroporto);
	}
	
	public Optional<Aeroporto> findById(Long id) {
		return aeroportos.findById(id);
	}
	
	public void deleteById(Long id) {
		aeroportos.deleteById(id);
	}
	
	public List<Voo> listaVoo(Long id_aeroporto){
		return aeroportos.findById(id_aeroporto).get().getVoos();
	}

}
