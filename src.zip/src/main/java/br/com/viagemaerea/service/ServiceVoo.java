package br.com.viagemaerea.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import br.com.viagemaerea.model.Passagem;
import br.com.viagemaerea.model.Voo;
import br.com.viagemaerea.repository.RepositoryVoo;

@Service
public class ServiceVoo {
	
	@Autowired
	private RepositoryVoo voos;
	
	public List<Voo> findAll(){
		return voos.findAll();
	}
	
	public void save(Voo voo) {
		voos.saveAndFlush(voo);
	}
	
	public Optional<Voo> findById(Long id) {
		return voos.findById(id);
	}
	
	public void deleteById(Long id) {
		voos.deleteById(id);
	}
	
	// Retornar uma lista de passagens
	public List<Passagem> listaPassagem(Long id_voo){
		return voos.findById(id_voo).get().getPassagens();
	}

}
