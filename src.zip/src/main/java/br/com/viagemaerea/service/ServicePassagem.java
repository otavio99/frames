package br.com.viagemaerea.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import br.com.viagemaerea.model.Passagem;
import br.com.viagemaerea.repository.RepositoryPassagem;

@Service
public class ServicePassagem {
	
	@Autowired
	private RepositoryPassagem passagens;
	
	public List<Passagem> findAll(){
		return passagens.findAll();
	}
	
	public void save(Passagem passagem) {
		passagens.saveAndFlush(passagem);
	}
	
	public Optional<Passagem> findById(Long id) {
		return passagens.findById(id);
	}
	
	public void deleteById(Long id) {
		passagens.deleteById(id);
	}
	
}
