package br.com.viagemaerea.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import br.com.viagemaerea.model.Cliente;
import br.com.viagemaerea.model.Passagem;
import br.com.viagemaerea.repository.RepositoryCliente;

@Service
public class ServiceCliente {
	
	@Autowired
	private RepositoryCliente clientes;
	
	public List<Cliente> findAll(){
		return clientes.findAll();
	}
	
	public void save(Cliente cliente) {
		clientes.saveAndFlush(cliente);
	}
	
	public Optional<Cliente> findById(Long id) {
		return clientes.findById(id);
	}
	
	public void deleteById(Long id) {
		clientes.deleteById(id);
	}
	
	// Retornar uma lista de passagens
	public List<Passagem> listaPassagem(Long id_cliente){
		return clientes.findById(id_cliente).get().getPassagens();
	}

}
