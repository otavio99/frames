package br.com.viagemaerea.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import br.com.viagemaerea.model.Aviao;
import br.com.viagemaerea.repository.RepositoryAviao;

@Service
public class ServiceAviao {
	@Autowired
	private RepositoryAviao avioes;
	
	public List<Aviao> findAll(){
		return avioes.findAll();
	}
	
	public void save(Aviao aviao) {
		avioes.saveAndFlush(aviao);
	}
	
	public Optional<Aviao> findById(Long id) {
		return avioes.findById(id);
	}
	
	public void deleteById(Long id) {
		avioes.deleteById(id);
	}
	
}
